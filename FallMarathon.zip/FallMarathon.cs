﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/// David Simmons
/// Marathon App
/// 9/7/2021



namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        /// Form load below

        private void Form1_Load(object sender, EventArgs e)
        {

        }



        /// Below are buttons that display alerts with the information asked for.

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Start Time: 8:00 AM");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("May 30, 2017");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ryan Park");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("For more information, view the Fall Marathon Facebook page.");
        }
    }
}
