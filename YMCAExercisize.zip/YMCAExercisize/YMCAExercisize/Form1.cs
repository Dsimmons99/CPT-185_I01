﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMCAExercisize
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            String T2 = textBox1.Text;
            int day1 = Convert.ToInt32(numericUpDown1.Value);
            int day2 = Convert.ToInt32(numericUpDown2.Value);
            int day1Hours = day1 * 24;
            int day2Hours = day2 * 24;

            int month1 = Convert.ToInt32(numericUpDown3.Value);
            int month2 = Convert.ToInt32(numericUpDown4.Value);
            int month1Hours = month1 * 720;
            int month2Hours = month2 * 720;

            int year1 = Convert.ToInt32(numericUpDown5.Value);
            int year2 = Convert.ToInt32(numericUpDown6.Value);
            int year1Hours = year1 * 8760;
            int year2Hours = year2 * 8760;


            int hours = (day1Hours - day2Hours) + (month1Hours - month2Hours) + (year1Hours - year2Hours);
            double total = hours * 1 / 7 * 3;

            MessageBox.Show(T2 + " has worked out for " + total + " hours");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown6_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value != 0)
            {
                numericUpDown1.Value = 0;
            }

            if (numericUpDown2.Value != 0)
            {
                numericUpDown2.Value = 0;
            }

            if (numericUpDown3.Value != 0)
            {
                numericUpDown3.Value = 0;
            }

            if (numericUpDown4.Value != 0)
            {
                numericUpDown4.Value = 0;
            }

            if (numericUpDown5.Value != 0)
            {
                numericUpDown5.Value = 0;
            }

            if (numericUpDown6.Value != 0)
            {
                numericUpDown6.Value = 0;
            }
        }
    }
}